Url - https://www.kaggle.com/datasets/ahsenwaheed/youtube-comments-spam-dataset/data
