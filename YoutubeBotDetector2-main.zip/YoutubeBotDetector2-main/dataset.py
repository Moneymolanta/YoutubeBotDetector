
import kagglehub
import torch
import numpy as np
import pandas as pd

"""
This file gets the info on the dataset.
"""
    
